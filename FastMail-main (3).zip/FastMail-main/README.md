*********************************************************************MUST READ**************************************************************************************************

click on the download zip button and download the files. before you open the application in the folder, go to myaccount.google.com/lesssecureapps and turn the allow less secure apps: ON. Don't worry, this is completely safe. Once you enter your credentials in the mail application, and send the mail, you can turn it off!
HAVE A GREAT TIME :)
